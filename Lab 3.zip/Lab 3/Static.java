import java.util.Scanner;
class Main {
    static int n;

    public static void main(String[] args){
    Scanner s= new Scanner (System.in);
    n=s.nextInt();
    System.out.println(n);
    s.close();
}
}