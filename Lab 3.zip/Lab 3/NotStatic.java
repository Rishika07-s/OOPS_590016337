import java.util.Scanner;
class Main {
    

    public static void main(String[] args){
    Scanner s= new Scanner (System.in);
    int n;
    n=s.nextInt();
    System.out.println(n);
    s.close();
}
}