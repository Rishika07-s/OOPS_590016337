import java.util.Scanner;

class Main{
    int n;
    public static void main(String[] args) {
        Scanner s= new Scanner (System.in);
        Main m=new Main();
        
        m.n=s.nextInt();
        System.out.println(m.n);
    }
}