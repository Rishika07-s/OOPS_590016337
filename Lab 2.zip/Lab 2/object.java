import java.util.Scanner;
public class object {
    int m;
    public static void main(String[] args){
     Scanner s = new Scanner(System.in);
     object n=new object();
        n.m=s.nextInt();
        System.out.println("Enter teh value of n"+n.m);

    }
}